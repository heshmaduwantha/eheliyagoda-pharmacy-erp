# QA Progress Checkpoint

Last updated: 2026-09-05, Asia/Colombo

## Completed — do not repeat

- Full repository file inventory, Prisma schema and primary business services inspected.
- Architecture and module implementation status documented.
- Safety boundary established: remote `.env` database was not mutated.
- Dedicated local PostgreSQL database `pharmacy_erp_qa` created with all 13 migrations.
- Deterministic synthetic owner/pharmacist and baseline catalog seeded locally.
- Original automated suite run against QA DB: **52 passed, 0 failed**.
- Added and executed 12 independent business-reconciliation tests: **5 passed, 7 failed**.
- Concurrency test proved simultaneous demand above stock cannot create negative quantity.
- UI/API QA executed at `http://localhost:3100` using local Chrome/Playwright against QA DB.
- Architecture, dataset, master plan, scenario matrix, defect report, safe runner and invariant SQL created.

## Confirmed defects

1. CRITICAL — alternate-UOM selling prices normalized twice in POS and checkout.
2. CRITICAL — alternate-UOM cost normalized twice in valuation and sale COGS.
3. HIGH — supplier return can reduce another supplier's invoice.
4. HIGH — database accepts zero UOM conversion factor.
5. HIGH — already-expired medicine GRN can be confirmed.
6. HIGH — inactive product GRN can be confirmed.
7. LOW — external login texture returns HTTP 404.

## Current execution totals

- Automated: 64 executed, 57 passed, 7 failed.
- UI/API checks: 6 executed, 5 passed, 1 failed (decorative 404).
- Overall executed: 70; passed 62; failed 8.
- No production data used. No confirmed defect was automatically fixed.

## Completion state

- Execution, reconciliation and traceability reports completed.
- TypeScript, diff and production build validation passed.
- Failing business tests preserved as regression specifications.
- Temporary QA web server stopped after evidence collection.
- Next phase is defect remediation, followed by rerunning this baseline; remediation was outside this QA-only request.

## Deferred coverage requiring product scope or policy

- Repeating-decimal inventory costing policy.
- Real barcode hardware behavior.
- Branch transfers, PO partial receipt, partial sales returns, customer credit, cash-register closing, tax engine and GL accounting are not implemented.
